"""Updated offline explorer; original project credited in README and manifest."""
from pathlib import Path
import streamlit as st
from dataset_utils import (DatasetError, enrich_records, export_frame, filter_data,
                           language_summary, read_jsonl, read_seed)

ROOT = Path(__file__).resolve().parent
DATA_FILE = ROOT / "privacy_threat_dataset.jsonl"
SEED_FILE = ROOT / "dataset_source.json"
LANGUAGES = {"ru": "Русский (ru)", "kk": "Қазақша (kk)", "en": "English (en)"}

st.set_page_config(page_title="Датасет: Нарушение конфиденциальности (Задание №6)",
                   page_icon="🛡️", layout="wide")
st.title("🛡️ Датасет: Нарушение конфиденциальности")
st.caption("Задание №6 · PRIVACY_THREAT · офлайн-обзор учебных примеров")
st.info("Набор содержит шаблонные учебные примеры и их повторения. Поле source сохранено "
        "из исходного проекта: оно описывает предполагаемый контекст, но не подтверждает "
        "сбор сообщения на указанной платформе. Подтверждённых ссылок на первоисточники нет.")

@st.cache_data(show_spinner=False)
def load_data(data_stamp, seed_stamp):
    # Signatures invalidate cache on local edits; explicit reload is also available.
    return enrich_records(read_jsonl(DATA_FILE), read_seed(SEED_FILE))

st.sidebar.header("🔄 Деректер / Данные")
if st.sidebar.button("Перечитать локальные файлы", key="reload_data"):
    load_data.clear()
st.sidebar.caption("Чтение JSONL с диска. Файлы не изменяются; интернет-сбор отключён.")

try:
    data_stat, seed_stat = DATA_FILE.stat(), SEED_FILE.stat()
    df = load_data((data_stat.st_mtime_ns, data_stat.st_size),
                   (seed_stat.st_mtime_ns, seed_stat.st_size))
except (OSError, DatasetError) as exc:
    st.error(f"Не удалось загрузить данные: {exc}")
    st.info("Восстановите privacy_threat_dataset.jsonl и dataset_source.json из резервной копии. "
            "Приложение не заменяет полный набор базовыми 48 примерами.")
    st.stop()

options = {
    "filter_languages": sorted(df["language"].unique().tolist()),
    "filter_platforms": sorted(df["platform"].unique().tolist()),
    "filter_sources": sorted(df["source"].unique().tolist()),
    "filter_labels": sorted(df["sub_label"].unique().tolist()),
}
for key, values in options.items():
    if key not in st.session_state:
        st.session_state[key] = list(values)
    else:
        # Preserve deliberate empty selections while dropping obsolete options.
        st.session_state[key] = [v for v in st.session_state[key] if v in values]

def reset_filters():
    for key, values in options.items():
        st.session_state[key] = list(values)
    st.session_state["search_query"] = ""

st.sidebar.header("🔍 Сүзгілер / Фильтры")
st.sidebar.button("Сбросить фильтры", on_click=reset_filters, key="reset_filters")
query = st.sidebar.text_input("Мәтін бойынша іздеу / Поиск", key="search_query",
                              placeholder="Например: [ИМЯ] или номер")
st.sidebar.caption("Поиск буквальный, без регулярных выражений. Пустой выбор в любом списке даёт 0 строк.")
selected_languages = st.sidebar.multiselect("Тіл / Язык", options["filter_languages"],
    format_func=lambda value: LANGUAGES.get(value, value), key="filter_languages")
selected_platforms = st.sidebar.multiselect("Платформа", options["filter_platforms"], key="filter_platforms")
selected_sources = st.sidebar.multiselect("Дереккөз / Описание источника", options["filter_sources"], key="filter_sources")
selected_labels = st.sidebar.multiselect("Бұзушылық түрлері / Подклассы", options["filter_labels"], key="filter_labels")
filtered = filter_data(df, languages=selected_languages, platforms=selected_platforms,
                       sources=selected_sources, sub_labels=selected_labels, query=query)

c1, c2, c3, c4 = st.columns(4)
c1.metric("Всего записей", len(df))
c2.metric("Отфильтровано", len(filtered))
c3.metric("Языков в наборе", language_summary(df))
c4.metric("Уникальных текстов в наборе", df["text"].nunique())
st.caption(f"Повторных текстов: {len(df) - df['text'].nunique():,}. "
           f"Совпадений с базовыми шаблонами: {(df['origin_status'] == 'template_match').sum():,} "
           f"из {len(df):,}; базовых примеров: {df['base_example_id'].nunique()}.")

if filtered.empty:
    st.warning("Ничего не найдено. Измените поиск или сбросьте фильтры.")
else:
    left, right = st.columns(2)
    with left:
        st.subheader("📊 Подкластар / Подклассы")
        st.bar_chart(filtered["sub_label"].value_counts().rename("Записей"), horizontal=True)
    with right:
        st.subheader("🌐 Платформы по описанию источника")
        st.bar_chart(filtered["platform"].value_counts().rename("Записей"), horizontal=True)
    st.caption("Смешанные описания сохранены отдельными группами: каждая запись учитывается один раз. "
               "Группировка не является подтверждением происхождения.")

st.subheader("📋 Таблица данных")
display_columns = ["id", "sub_label", "platform", "source", "text", "language", "origin_status", "base_example_id"]
display_columns += [c for c in df.columns if c not in display_columns]
st.dataframe(filtered[display_columns], width="stretch", height=460, hide_index=True)

st.subheader("📥 Скачать датасет")
scope = st.radio("Объём экспорта", ["Отфильтрованные записи", "Весь набор"],
                 horizontal=True, key="export_scope")
include_derived = st.checkbox("Добавить вычисленные поля platform, base_example_id и origin_status",
                              value=False, key="include_derived")
export_df = filtered if scope == "Отфильтрованные записи" else df
st.caption(f"В выгрузке: {len(export_df):,} записей. Исходные значения и порядок строк сохранены. "
           "CSV не меняет текст ради защиты от формул: импортируйте непроверенные значения в Excel как текст.")
suffix = "filtered" if scope == "Отфильтрованные записи" else "full"
for col, kind, label, extension, mime in zip(st.columns(3), ("csv", "excel", "jsonl"),
        ("CSV · UTF-8", "Excel CSV · UTF-8 BOM · ;", "JSONL · UTF-8"),
        ("csv", "csv", "jsonl"), ("text/csv", "text/csv", "application/x-ndjson")):
    col.download_button(label, export_frame(export_df, kind, include_derived=include_derived),
        file_name=f"privacy_threat_{suffix}_{kind}.{extension}", mime=mime, key=f"download_{kind}")

with st.expander("📖 Подклассы и качество данных"):
    st.markdown("""
    - DOXING: публикация персональных данных
    - DOXING_THREAT: угроза публикации данных
    - PHONE_DISCLOSURE: публикация номера телефона
    - ADDRESS_DISCLOSURE: публикация адреса
    - LOCATION_DISCLOSURE: раскрытие местоположения
    - IDENTITY_DISCLOSURE: раскрытие личности анонимного пользователя
    - PRIVATE_MESSAGE_LEAK: публикация личной переписки
    - INTIMATE_CONTENT_LEAK: распространение интимных материалов
    - PERSONAL_DATA_REQUEST: запрос персональных данных

    Токены: [ИМЯ], [ТЕЛЕФОН], [АДРЕС], [EMAIL], [АККАУНТ], [ГЕОЛОКАЦИЯ].
    Поле is_anonymized — сохранённая авторская метка, не независимый аудит.
    Наличие токенов не гарантирует отсутствие всех персональных данных или соответствие законам.

    origin_status=template_match означает точное совпадение текста, метки, языка и описания
    источника с базовым примером или его известным префиксным вариантом; unverified — совпадение
    не установлено. Это вычисляемая характеристика, не история реального сбора.

    Повторения и близкие варианты нельзя случайно разносить между train и test: иначе возможна
    утечка шаблонов и завышенная оценка. Группируйте по base_example_id, проверяйте близкие
    тексты и используйте независимый контрольный набор. Качество обученной модели не оценивалось.
    Полного текста задания №6 в репозитории нет; соответствие всем критериям не проверено.
    """)
st.caption("Исходный проект: ruslankyzyanais17-wq/01_data_generation-main-streamlit_app.py. "
           "Локальная доработанная копия; версия и сохранённые оригиналы — в README.")
